# Calculateur Mahjong MCR

Version de référence : **V12**.

Ce dépôt publie l'application via **GitHub Pages**, depuis la branche `main`, dossier `/ (root)`.

## Installation
1. Créer un dépôt public nommé `calculateur-mcr` dans votre compte GitHub.
2. Décompresser l'archive fournie.
3. Importer les **fichiers et dossiers contenus dans l'archive**, en conservant leur arborescence. 
   Ne pas importer seulement le ZIP : GitHub ne décompresse pas les ZIP sur la page d'import.
4. Dans Settings > Pages : Source = `Deploy from a branch`, Branch = `main`, Folder = `/ (root)`, puis Save.
5. Visiter `https://VOTRE-PSEUDO.github.io/calculateur-mcr/`.

## Attention
- Le dépôt GitHub public rend le code source et les illustrations publiquement visibles.
- Ne jamais placer dans ce dépôt de mots de passe, clés privées ou sauvegardes personnelles.
- Les données du navigateur liées à l'ancien domaine Netlify ne sont pas transférées automatiquement.
- Conserver le jeu de tuiles original et les règles MCR du projet.
