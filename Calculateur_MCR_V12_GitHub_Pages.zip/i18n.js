/* Mahjong MCR V12 : couche d'interface français / chinois simplifié.
   La logique de calcul de la V11 reste inchangée. Les textes proviennent de
   traductions d'interface et des 81 noms officiels chinois du MCR (WMO).
   Ce module ne modifie ni les IDs, ni les scores, ni les inclusions de fans. */
(() => {
  'use strict';
  const DATA = {"ui":{"/V12 · Tuiles originales":"/ V12 · 原版牌面","Le calculateur de main":"麻将计分器","Chaque tuile":"每张牌","compte.":"都很重要。","Compose ta main avec de":"使用","tuiles illustrées fidèles aux originales":"忠实呈现原版图案的麻将牌",", indique les conditions de victoire et découvre une proposition de décompte selon les":"，设置和牌条件，并根据","81 fan MCR":"81种国标麻将番种",". Ajuste ensuite le résultat manuellement pour les cas subtils.":"获得计分建议。复杂情况可手动调整。","Construire la main":"组建手牌","↺ Réinitialiser":"↺ 重置","Ajoute tes tuiles cachées (jusqu’à 14, moins 3 par élément déclaré). Clique sur la tuile gagnante dans ta main pour marquer":"添加暗牌（最多14张；每副已亮明的面子减3张）。点击手牌中的和牌张，将其标记为",". Les kongs ajoutent une quatrième tuile physique.":"。杠牌会额外增加一张实体牌。","⚠ Aperçu statique : les boutons ne peuvent pas fonctionner ici.":"⚠ 静态预览：此处的按钮无法操作。","Si tu vois ce message, le JavaScript du calculateur n'est pas exécuté dans cet aperçu de fichier. Les tuiles sont montrées ci-dessous mais ne sont pas":"如出现此提示，说明当前预览未执行计算器脚本。下方仅展示牌面，无法操作；请在浏览器中打开网页。","Safari à une adresse web":"通过 Safari 打开网页","(voir le guide fourni avec le ZIP).":"（请参阅压缩包内的说明）。","Mode de saisie":"输入方式","Tuile cachée":"暗牌","＋ Chow exposé":"＋ 明顺（吃）","＋ Pung exposé":"＋ 明刻（碰）","＋ Kong exposé":"＋ 明杠","＋ Kong caché":"＋ 暗杠","Clique sur une tuile pour l’ajouter à ta main cachée.":"点击麻将牌，将其加入暗牌。","Choisis le DÉBUT du chow (1 à 7). Trois tuiles seront ajoutées dans les éléments exposés.":"选择顺子的起始牌（1至7），三张牌将加入明牌区。","Clique une tuile pour ajouter son pung exposé (trois exemplaires).":"点击麻将牌以添加一副明刻（三张相同的牌）。","Clique une tuile pour ajouter un kong exposé (quatre exemplaires).":"点击麻将牌以添加一副明杠（四张相同的牌）。","Clique une tuile pour ajouter un kong caché ; il reste compatible avec une main cachée.":"点击麻将牌以添加一副暗杠；暗杠不影响门前清。","Caractères":"万子","Cercles":"筒子","Bambous":"条子","Vents et dragons":"风牌与箭牌","Ta main et les éléments déclarés":"手牌与已声明面子","TUILES CACHÉES":"暗牌","En construction":"尚未完成","Main saisie":"手牌已录入","Tes tuiles apparaîtront ici.":"你的麻将牌将显示在这里。","CHOW / PUNG / KONG DÉCLARÉS":"已声明的顺子 / 刻子 / 杠","Aucun élément déclaré.":"尚无已声明的面子。","Appuie sur":"点击","un seul exemplaire physique":"其中一张实体牌","pour désigner la":"以指定","tuile gagnante HU":"和牌张（和）",". Utilise la petite croix pour la retirer. Pour un chow, sélectionne sa première tuile (1 à 7).":"。点击小叉可移除该牌。输入顺子时，请选择第一张牌（1至7）。","⌕ Trouver les tuiles gagnantes (13 tuiles)":"⌕ 分析听牌（13张牌）","Découvrir un exemple":"查看示例","Grande suite mixte":"花龙","Sept paires":"七对","Quatre grands vents":"大四喜","Circonstances":"和牌条件","VENT DOMINANT (MANCHE)":"圈风","VENT DU JOUEUR":"门风","Est":"东","Sud":"南","Ouest":"西","Nord":"北","Comment la main a-t-elle gagné ?":"和牌方式","◈ Tiré soi-même":"◈ 自摸","⬡ Sur défausse":"⬡ 点和","Dernière tuile tirée":"妙手回春（最后一张自摸）","Dernière tuile jetée":"海底捞月（最后一张弃牌）","Sur remplacement d’un kong":"杠上开花","Vol d’un kong":"抢杠和","Dernière tuile existante (3 autres visibles — à vérifier)":"和绝张（三张已可见，请核实）","Fleurs et saisons exposées":"亮明的花牌与季节牌","1 point chacune,":"每张计1分，","hors des 8 points nécessaires pour annoncer HU":"不计入起和所需的8分","Décompte":"计分结果","✧ Proposition auto":"✧ 自动计分建议","✎ Décompte manuel":"✎ 手动计分","Total de la main":"本手牌总分","points":"分","point":"分","FANS":"番种数","POINTS (HORS FLEURS)":"番种得分（不含花牌）","FLEURS":"花牌","Important :":"注意：","le calcul automatique est une":"自动计算仅供","aide au décompte":"辅助计分",", pas une validation d’arbitre. Les règles d’inclusion, d’exclusion et d’optimisation des 81 fans peuvent produire des cas délicats. En mode manuel, vérifie et corrige les fans à l’aide de la fiche officielle.":"参考，并非裁判确认。81种番种的包含、排除与组合规则可能涉及复杂情况。请依据官方规则在手动模式中核对并修正。","Répartition des points de la donne":"本局四家得分","JOUEUR GAGNANT":"和牌者","DÉFAUSSEUR":"点炮者","Points nets à la table hors pénalités.":"四家净得分（不含罚分）。","Copier le décompte":"复制计分结果","Imprimer":"打印","Les 81 fans":"81种番种","Catalogue complet":"全部番种","Recherche chaque combinaison par nom ou numéro. En mode manuel, sélectionne ou retire un fan pour composer ton propre décompte.":"按名称或编号搜索番种。在手动模式中，可选择或取消番种来自行计算分数。","Tous":"全部","Mes fans":"我的番种","Fan n° 81 : les fleurs sont comptées exclusivement dans la zone « Fleurs et saisons ».":"第81项为花牌，仅在「花牌与季节牌」区域计分。","Mahjong MCR — atelier personnel":"国标麻将 MCR — 个人练习工具","Référence MCR européenne : Green Book WMO 2006 (EMA) ; pour les cumuls de Kongs, interprétation publiée par le comité des règles MCR de l’EMA en septembre 2023.":"欧洲MCR规则参考：世界麻将组织绿皮书（EMA采用）；杠牌组合参见EMA MCR规则委员会2023年9月的解释。","Prunier":"梅","Orchidée":"兰","Chrysanthème":"菊","Bambou":"竹","Printemps":"春","Été":"夏","Automne":"秋","Hiver":"冬","Dragon rouge":"红中","Dragon vert":"发财","Dragon blanc":"白板","Chow":"顺子","Pung":"刻子","Kong exposé":"明杠","Kong caché":"暗杠","Supprimer cet élément":"删除该面子","Pas de transfert validé : la main doit être complète et totaliser au moins 8 points hors fleurs.":"尚不能结算：手牌必须完整，且不含花牌的番种得分至少为8分。","Résultat net des quatre joueurs (somme nulle), sans pénalités. Le forfait de 8 points est payé par chaque perdant.":"四家净得分（总和为零，不含罚分）。每名未和牌者另须支付8分底分。","Choisis un défausseur différent du gagnant.":"请选择与和牌者不同的点炮者。","Décompte manuel — structure non vérifiée.":"手动计分——尚未验证和牌结构。","Aucune combinaison sélectionnée.":"尚未选择任何番种。","Les fans possibles apparaissent ici dès que la main est complète et que sa tuile gagnante est identifiée.":"手牌完整并指定和牌张后，可能的番种将显示在这里。","Fleurs et saisons":"花牌与季节牌","(bonus)":"（加分）","Décompte personnalisé : la compatibilité des fan cochés relève de ta vérification.":"自定义计分：所选番种能否同时计分，请自行核对规则。","Cumuls de Chows potentiellement chevauchants : les occurrences d’un même fan sont limitées, mais les associations entre fans différents nécessitent un contrôle manuel (règle EMA de comptage unique).":"顺子番种可能重叠：同一种番种的计数已有限制，但不同番种之间的组合仍须人工核对（EMA单次计分规则）。","Dernière tuile existante (#58) : vérifier que les trois autres exemplaires étaient déjà visibles sur la table avant la victoire.":"和绝张（第58项）：请确认和牌前另外三张相同牌均已亮明。","Aucun fan sélectionné dans le décompte manuel.":"手动计分中尚未选择任何番种。","Aucun fan comptabilisé pour la main en cours.":"当前手牌尚无计入得分的番种。","Aucun de mes fans ne correspond à cette recherche.":"我的番种中没有符合搜索条件的项目。","Afficher tous les fans":"显示全部番种","Aucun fan pour cette recherche.":"没有符合搜索条件的番种。","Diminuer le nombre":"减少数量","Augmenter le nombre":"增加数量","Aucune tuile ne complète une main MCR avec cette configuration.":"当前配置下，没有任何牌能够组成完整的MCR和牌。","✓ HU possible":"✓ 可以和牌","✕ Sous 8 points":"✕ 不足8分","Décompte copié !":"计分结果已复制！","La main est déjà vide.":"手牌已经是空的。","Ajoute les fleurs dans la zone « Fleurs et saisons ».":"请在「花牌与季节牌」区域添加花牌。","Retire une tuile ou recommence la main avant d’en ajouter.":"请先移除一张牌或重新开始。","Il n’existe que quatre exemplaires de cette tuile.":"每种麻将牌只有四张。","Quatre éléments déclarés au maximum.":"最多只能声明四副面子。","Retire d’abord des tuiles cachées : un élément déclaré occupe trois places.":"请先移除暗牌：每副已声明面子占三张牌的位置。","Le Chow doit commencer par une tuile 1 à 7.":"顺子必须从1至7开始。","Ce groupe dépasserait quatre exemplaires d’une tuile.":"这组牌会使某种牌超过四张。","Trop d’éléments déclarés.":"已声明的面子过多。","Impossible : plus de quatre exemplaires d’une même tuile.":"无效：某种牌超过四张。","Tuile gagnante absente de la main.":"和牌张不在手牌中。","La tuile gagnante ne correspond pas à la main.":"和牌张与手牌不符。","Si tu vois ce message, le JavaScript du calculateur n'est pas exécuté dans cet aperçu de fichier. Les tuiles sont montrées ci-dessous mais ne sont pas sélectionnables. Pour utiliser le calculateur sur iPhone, ouvre-le depuis":"如果出现此提示，说明文件预览未执行计分器脚本。下方仅显示牌面，无法点击操作。若在iPhone上使用，请通过Safari打开在线网页。","Référence MCR européenne : Green Book WMO 2006 (EMA) ; pour les cumuls de Kongs, interprétation publiée par le comité des règles MCR de l’EMA en septembre 2012 et relayée par la Fédération italienne. Les 81 intitulés français suivent le texte fourni. Prototype non homologué ; contrôle humain recommandé.":"欧洲MCR参考规则：WMO 2006年《绿皮书》（EMA采用）。杠牌组合依据EMA规则委员会2012年9月的解释及意大利麻将协会转述。81个法文名称依照所提供的资料。此工具未经官方认证，建议人工核对。","· Application locale utilisable hors connexion · Visuels PNG originaux fournis par l’utilisateur, couleurs préservées. Décompte basé sur le document FFMJ fourni (édition traduite 2014) ; vérification nécessaire avant une compétition.":"· 支持离线使用 · 使用用户提供的原版PNG牌面，保留原始色彩。计分参照所提供的法国麻将联合会2014年译本；比赛前请核对。","Exemple d’interface inspiré de l’ergonomie du calculateur":"界面布局参考计分器","; aucun code du site repris.":"；未使用该网站的代码。","Fédération française de Mah-Jong":"法国麻将联合会","Indique la tuile gagnante dans la main cachée.":"请在暗牌中指定和牌张。","Dernière tuile existante impossible : une autre tuile identique est encore dans ta main cachée.":"无法计入和绝张：你的暗牌中仍有另一张相同牌。","La dernière tuile tirée impose une victoire à la pioche.":"妙手回春必须为自摸和牌。","Cette condition nécessite une victoire sur défausse.":"此条件要求点和。","Une tuile de remplacement de kong est tirée soi-même.":"杠上开花的补牌必须由自己摸取。","On ne peut pas voler un kong et finir sur son propre remplacement.":"不能同时抢杠和与杠上开花。","Dernière tuile existante (#58) : vérifier que les trois autres exemplaires étaient déjà visibles sur la table avant la victoire. Le calculateur ne dispose pas de l’historique des défausses.":"和绝张（第58项）：请确认和牌前另外三张相同牌已在桌面公开可见。计分器没有完整弃牌记录。","V10 : rappel des inclusions contrôlées et vérification supplémentaire de la dernière tuile existante. Les informations sur les défausses adverses ne sont pas accessibles au calculateur : vérification humaine requise. Prototype non homologué : contrôle humain recommandé.":"V10原有提示：已检查相关包含关系，并对和绝张作进一步提醒。计分器无法读取对手的弃牌历史，必须人工核对。本工具未经官方认证。","/ V12 · Tuiles originales":"/ V12 · 原版牌面","· Tuiles originales":"· 原版牌面"},"fans":[{"id":1,"frName":"Quatre Grands Vents","frDesc":"Un pung ou kong de chacun des quatre vents.","zhName":"大四喜","zhDesc":"东、南、西、北四种风牌各组成一副刻子或杠。"},{"id":2,"frName":"Trois Grands Dragons","frDesc":"Pungs ou kongs des trois dragons.","zhName":"大三元","zhDesc":"中、发、白三种箭牌各组成一副刻子或杠。"},{"id":3,"frName":"Main Verte","frDesc":"Main composée uniquement de 2, 3, 4, 6, 8 bambous et du dragon vert.","zhName":"绿一色","zhDesc":"和牌只使用二、三、四、六、八条以及发牌。"},{"id":4,"frName":"Neuf Portes","frDesc":"1112345678999 caché dans une famille, complété par une des neuf tuiles de cette famille.","zhName":"九莲宝灯","zhDesc":"同一种花色暗藏1112345678999，再以该花色任意一张序数牌和牌。"},{"id":5,"frName":"Quatre Kongs","frDesc":"Quatre kongs.","zhName":"四杠","zhDesc":"和牌包含四副杠牌。"},{"id":6,"frName":"Sept Paires Pures Consécutives","frDesc":"Sept paires numérotées consécutivement dans une seule famille.","zhName":"连七对","zhDesc":"同一花色中由七个连续数位的对子组成和牌。"},{"id":7,"frName":"Treize Orphelins","frDesc":"Une tuile de chaque honneur et extrémité, plus un doublon.","zhName":"十三幺","zhDesc":"六种一、九序数牌和七种字牌各一张，再将其中一种配成对子。"},{"id":8,"frName":"Tout Extrémité","frDesc":"Uniquement des pungs/kongs de 1 et 9 et une paire de 1 ou 9.","zhName":"清幺九","zhDesc":"只由一、九序数牌的刻子、杠及将牌组成。"},{"id":9,"frName":"Quatre Petits Vents","frDesc":"Trois pungs/kongs de vents et la paire du quatrième.","zhName":"小四喜","zhDesc":"三种风牌组成刻子或杠，第四种风牌作将。"},{"id":10,"frName":"Trois Petits Dragons","frDesc":"Deux pungs/kongs de dragons et la paire du troisième.","zhName":"小三元","zhDesc":"两种箭牌组成刻子或杠，第三种箭牌作将。"},{"id":11,"frName":"Tout Honneur","frDesc":"Uniquement des tuiles d’honneur.","zhName":"字一色","zhDesc":"和牌只由风牌和箭牌组成。"},{"id":12,"frName":"Quatre Pungs Cachés","frDesc":"Quatre pungs/kongs non exposés.","zhName":"四暗刻","zhDesc":"有四副未副露的刻子或暗杠。"},{"id":13,"frName":"Deux Dragons dans une Famille","frDesc":"Deux chows 123 et deux chows 789, avec la paire de 5, dans une seule famille.","zhName":"一色双龙会","zhDesc":"同一花色包含两组123、两组789，五作将牌。"},{"id":14,"frName":"Quadruple Chow Pur","frDesc":"Quatre chows identiques dans une famille.","zhName":"一色四同顺","zhDesc":"同一花色有四副相同的顺子。"},{"id":15,"frName":"Quatre Pungs Purs Consécutifs","frDesc":"Quatre pungs consécutifs dans une famille.","zhName":"一色四节高","zhDesc":"同一花色有四副数位依次相差一的刻子或杠。"},{"id":16,"frName":"Quatre Chows Purs Superposés","frDesc":"Quatre chows d’une famille décalés régulièrement de 1 ou 2.","zhName":"一色四步高","zhDesc":"同一花色有四副依次上升一位或两位的顺子。"},{"id":17,"frName":"Trois Kongs","frDesc":"Trois kongs.","zhName":"三杠","zhDesc":"和牌包含三副杠牌。"},{"id":18,"frName":"Tout Honneur et Extrémité","frDesc":"Main de pungs/kongs et paire constitués d’honneurs ou d’extrémités.","zhName":"混幺九","zhDesc":"由字牌及一、九序数牌组成刻子、杠和将牌。"},{"id":19,"frName":"Sept Paires","frDesc":"Sept paires (même une paire doublée peut compter).","zhName":"七对","zhDesc":"和牌由七个对子组成。"},{"id":20,"frName":"Grand Serpentin","frDesc":"Sept honneurs distincts et sept tuiles numérotées distinctes tricotées.","zhName":"七星不靠","zhDesc":"七种字牌各一张，加上依147、258、369分组的七张不重复序数牌。"},{"id":21,"frName":"Tout Pung Pair","frDesc":"Quatre pungs/kongs pairs et une paire paire.","zhName":"全双刻","zhDesc":"刻子、杠和将牌全部使用二、四、六、八序数牌。"},{"id":22,"frName":"Main Pure","frDesc":"Une seule famille numérotée, sans honneur.","zhName":"清一色","zhDesc":"和牌只使用一种花色的序数牌，没有字牌。"},{"id":23,"frName":"Triple Chow Pur","frDesc":"Trois chows identiques dans une famille.","zhName":"一色三同顺","zhDesc":"同一花色有三副相同的顺子。"},{"id":24,"frName":"Trois Pungs Purs Consécutifs","frDesc":"Trois pungs consécutifs dans une famille.","zhName":"一色三节高","zhDesc":"同一花色有三副数位依次相差一的刻子或杠。"},{"id":25,"frName":"Les Trois Derniers","frDesc":"Uniquement des numéros 7 à 9.","zhName":"全大","zhDesc":"和牌所有序数牌都是七、八、九。"},{"id":26,"frName":"Les Trois Milieux","frDesc":"Uniquement des numéros 4 à 6.","zhName":"全中","zhDesc":"和牌所有序数牌都是四、五、六。"},{"id":27,"frName":"Les Trois Premiers","frDesc":"Uniquement des numéros 1 à 3.","zhName":"全小","zhDesc":"和牌所有序数牌都是一、二、三。"},{"id":28,"frName":"Grande Suite Pure","frDesc":"Les chows 123, 456 et 789 dans une même famille.","zhName":"清龙","zhDesc":"同一花色包含123、456、789三副顺子。"},{"id":29,"frName":"Deux Dragons dans Trois Familles","frDesc":"Deux couples 123 et 789 dans deux familles, avec paire de 5 dans la troisième.","zhName":"三色双龙会","zhDesc":"两种花色各有123和789，第三种花色的五作将。"},{"id":30,"frName":"Trois Chows Purs Superposés","frDesc":"Trois chows d’une famille décalés régulièrement de 1 ou 2.","zhName":"一色三步高","zhDesc":"同一花色有三副依次上升一位或两位的顺子。"},{"id":31,"frName":"Cinq Partout","frDesc":"Chaque élément, y compris la paire, contient un 5.","zhName":"全带五","zhDesc":"每副牌以及将牌都包含五。"},{"id":32,"frName":"Triple Pung","frDesc":"Trois pungs/kongs du même chiffre, dans les trois familles.","zhName":"三同刻","zhDesc":"三种花色中有三副数位相同的刻子或杠。"},{"id":33,"frName":"Trois Pungs Cachés","frDesc":"Trois pungs/kongs non exposés.","zhName":"三暗刻","zhDesc":"和牌中有三副暗刻或暗杠。"},{"id":34,"frName":"Petit Serpentin","frDesc":"Main tricotée avec cinq ou six honneurs différents.","zhName":"全不靠","zhDesc":"从三花色147、258、369及七种字牌中取14张互不相同且不靠张的牌。"},{"id":35,"frName":"Suite Serpentin","frDesc":"Une suite tricotée de neuf tuiles + un élément et une paire.","zhName":"组合龙","zhDesc":"三种花色分别按147、258、369组成九张特殊连续组合。"},{"id":36,"frName":"Les Quatre Derniers","frDesc":"Uniquement des numéros 6 à 9.","zhName":"大于五","zhDesc":"和牌的序数牌只包含六、七、八、九。"},{"id":37,"frName":"Les Quatre Premiers","frDesc":"Uniquement des numéros 1 à 4.","zhName":"小于五","zhDesc":"和牌的序数牌只包含一、二、三、四。"},{"id":38,"frName":"Trois Grands Vents","frDesc":"Trois pungs/kongs de vents.","zhName":"三风刻","zhDesc":"有三种风牌的刻子或杠。"},{"id":39,"frName":"Grande Suite","frDesc":"Chows 123, 456 et 789 dans les trois familles différentes.","zhName":"花龙","zhDesc":"三种不同花色分别组成123、456、789顺子。"},{"id":40,"frName":"Symétrie","frDesc":"Uniquement des tuiles à symétrie centrale.","zhName":"推不倒","zhDesc":"只使用图案上下翻转不变的允许牌张。"},{"id":41,"frName":"Triple Chow","frDesc":"Trois chows identiques dans les trois familles.","zhName":"三色三同顺","zhDesc":"三种花色各有一副数位相同的顺子。"},{"id":42,"frName":"Trois Pungs Consécutifs","frDesc":"Trois pungs de valeurs consécutives dans les trois familles.","zhName":"三色三节高","zhDesc":"三种花色中三副刻子或杠数位依次相差一。"},{"id":43,"frName":"Main Sans Valeur","frDesc":"Aucun autre fan applicable (hors fleurs).","zhName":"无番和","zhDesc":"除花牌以外，没有任何其他可计分番种的和牌。"},{"id":44,"frName":"Dernière Tuile Tirée","frDesc":"Victoire sur la dernière tuile piochée du mur.","zhName":"妙手回春","zhDesc":"自摸牌墙上的最后一张牌和牌。"},{"id":45,"frName":"Dernière Tuile Jetée","frDesc":"Victoire sur la dernière défausse de la partie.","zhName":"海底捞月","zhDesc":"和他人打出的最后一张牌。"},{"id":46,"frName":"Finir sur Kong","frDesc":"Victoire sur une tuile remplaçant un kong.","zhName":"杠上开花","zhDesc":"开杠后摸补牌而和牌。"},{"id":47,"frName":"Voler le Kong","frDesc":"Victoire sur une tuile utilisée pour compléter un kong ajouté.","zhName":"抢杠和","zhDesc":"和他人加杠时使用的那张牌。"},{"id":48,"frName":"Deux Kongs Cachés","frDesc":"Deux kongs cachés.","zhName":"双暗杠","zhDesc":"和牌包含两副暗杠。"},{"id":49,"frName":"Tout Pung","frDesc":"Quatre pungs/kongs et une paire.","zhName":"碰碰和","zhDesc":"四副刻子或杠加上一对将牌。"},{"id":50,"frName":"Semi-Pure","frDesc":"Une seule famille numérotée, avec au moins un honneur.","zhName":"混一色","zhDesc":"和牌由一种花色的序数牌和字牌组成。"},{"id":51,"frName":"Trois Chows Superposés","frDesc":"Trois chows décalés d’un numéro dans les trois familles.","zhName":"三色三步高","zhDesc":"三种花色各有一副数位依次递增一的顺子。"},{"id":52,"frName":"Tout Type","frDesc":"Caractères, cercles, bambous, vents et dragons présents.","zhName":"五门齐","zhDesc":"和牌同时包含万、筒、条、风牌和箭牌。"},{"id":53,"frName":"Tout Exposé","frDesc":"Quatre éléments exposés et victoire sur défausse pour la paire.","zhName":"全求人","zhDesc":"四副牌都是副露的吃、碰或明杠，并在点和时完成将牌。"},{"id":54,"frName":"Deux Dragons","frDesc":"Deux pungs/kongs de dragons.","zhName":"双箭刻","zhDesc":"有两种箭牌的刻子或杠。"},{"id":55,"frName":"Extrémité ou Honneur partout","frDesc":"Chaque élément, y compris la paire, contient une extrémité ou un honneur.","zhName":"全带幺","zhDesc":"每副牌和将牌都含一、九或字牌。"},{"id":56,"frName":"Tout Caché Tiré","frDesc":"Main non exposée gagnée par pioche personnelle.","zhName":"不求人","zhDesc":"没有吃、碰或明杠，并以自摸和牌。"},{"id":57,"frName":"Deux Kongs Exposés","frDesc":"Deux kongs exposés (un caché et un exposé valent 6 points).","zhName":"双明杠","zhDesc":"和牌有两副明杠；一明杠一暗杠的情形另计分。"},{"id":58,"frName":"Dernière Tuile Existante","frDesc":"Victoire sur la quatrième tuile d’un type, les trois autres étant visibles.","zhName":"和绝张","zhDesc":"和牌用的牌是同种牌最后一张，其余三张都已可见。"},{"id":59,"frName":"Pung de Dragon","frDesc":"Un pung/kong de dragon.","zhName":"箭刻","zhDesc":"中、发、白其中一种组成刻子或杠。"},{"id":60,"frName":"Vent Dominant","frDesc":"Un pung/kong du vent dominant.","zhName":"圈风刻","zhDesc":"有与本圈圈风相同的风牌刻子或杠。"},{"id":61,"frName":"Vent du Joueur","frDesc":"Un pung/kong du vent du joueur.","zhName":"门风刻","zhDesc":"有与自己座位门风相同的风牌刻子或杠。"},{"id":62,"frName":"Tout Caché Donné","frDesc":"Main non exposée gagnée sur défausse.","zhName":"门前清","zhDesc":"没有吃、碰或明杠，并以他人的弃牌和牌。"},{"id":63,"frName":"Tout Chow","frDesc":"Quatre chows et une paire sans honneur.","zhName":"平和","zhDesc":"四副顺子以及由序数牌组成的将牌。"},{"id":64,"frName":"Quatre Identiques","frDesc":"Quatre exemplaires d’une tuile sans kong.","zhName":"四归一","zhDesc":"和牌中有四张相同牌，但没有组成杠。"},{"id":65,"frName":"Double Pung","frDesc":"Deux pungs/kongs du même chiffre dans deux familles.","zhName":"双同刻","zhDesc":"两种花色中有两个数位相同的刻子或杠。"},{"id":66,"frName":"Deux Pungs Cachés","frDesc":"Deux pungs/kongs non exposés.","zhName":"双暗刻","zhDesc":"有两副未副露的刻子或暗杠。"},{"id":67,"frName":"Kong Caché","frDesc":"Un kong caché.","zhName":"暗杠","zhDesc":"自己摸齐四张相同牌开出的杠。"},{"id":68,"frName":"Tout Ordinaire","frDesc":"Toutes les tuiles sont numérotées de 2 à 8.","zhName":"断幺","zhDesc":"和牌中不含一、九或任何字牌。"},{"id":69,"frName":"Double Chow Pur","frDesc":"Deux chows identiques dans la même famille.","zhName":"一般高","zhDesc":"同一种花色有两副相同的顺子。"},{"id":70,"frName":"Double Chow","frDesc":"Deux chows identiques dans deux familles.","zhName":"喜相逢","zhDesc":"两种花色有两副数位相同的顺子。"},{"id":71,"frName":"Petite Suite Pure","frDesc":"Deux chows consécutifs (123+456, etc.) dans une famille.","zhName":"连六","zhDesc":"同一花色有两副数位相连的顺子，合成连续六张。"},{"id":72,"frName":"Deux Chows Purs d’Extrémités","frDesc":"Chows 123 et 789 dans la même famille.","zhName":"老少副","zhDesc":"同一种花色同时包含123和789顺子。"},{"id":73,"frName":"Pung de Vent ou d’Extrémité","frDesc":"Pung/kong de 1 ou 9, ou d’un vent non autrement valorisé.","zhName":"幺九刻","zhDesc":"有一、九序数牌或字牌组成的刻子或杠。"},{"id":74,"frName":"Kong Exposé","frDesc":"Un kong exposé.","zhName":"明杠","zhDesc":"利用他人弃牌或在明刻上加一张自摸牌组成的杠。"},{"id":75,"frName":"Une Famille Absente","frDesc":"Au moins une famille numérotée est absente.","zhName":"缺一门","zhDesc":"和牌没有其中一种花色的序数牌。"},{"id":76,"frName":"Pas d’Honneur","frDesc":"Aucun honneur.","zhName":"无字","zhDesc":"和牌不含风牌和箭牌。"},{"id":77,"frName":"Finir d’un Côté","frDesc":"Attente unique pour 3 sur 12 ou 7 sur 89.","zhName":"边张","zhDesc":"只等123中的三，或789中的七来和牌。"},{"id":78,"frName":"Finir au Milieu","frDesc":"Attente unique pour compléter l’intérieur d’un chow.","zhName":"坎张","zhDesc":"只等顺子中间的一张牌来和牌。"},{"id":79,"frName":"Finir sur la Paire","frDesc":"Attente unique pour compléter la paire.","zhName":"单调将","zhDesc":"只等一张牌来完成将牌对子。"},{"id":80,"frName":"Tirer Soi-même","frDesc":"Tuile gagnante tirée soi-même.","zhName":"自摸","zhDesc":"自己从牌墙摸到和牌所需的牌。"},{"id":81,"frName":"Fleur ou Saison","frDesc":"Chaque fleur ou saison exposée vaut un point hors minimum des huit.","zhName":"花牌","zhDesc":"每张花牌计一分，但不计入起和所需的八分。"}]};
  const UI = DATA.ui;
  const FANS_ZH = DATA.fans;
  const byName = new Map();
  for (const f of FANS_ZH) {
    byName.set(f.frName, f.zhName);
    byName.set(f.frDesc, f.zhDesc);
  }
  let locale = 'fr';
  const nodeOriginal = new WeakMap();
  const attributeOriginal = new WeakMap();
  const select = document.getElementById('languageSelect');
  if (!select) return;
  const tileNames = Object.freeze({
    'Est':'东','Sud':'南','Ouest':'西','Nord':'北',
    'Dragon rouge':'红中','Dragon vert':'发财','Dragon blanc':'白板',
    'Prunier':'梅','Orchidée':'兰','Chrysanthème':'菊','Bambou':'竹',
    'Printemps':'春','Été':'夏','Automne':'秋','Hiver':'冬'
  });
  const tileName = (name) => {
    const t = String(name).trim();
    if (tileNames[t]) return tileNames[t];
    const m = /^(\d+) (caractère|cercle|bambou)$/.exec(t);
    return m ? m[1] + ({'caractère':'万','cercle':'筒','bambou':'条'}[m[2]]) : null;
  };
  const zh = (raw) => {
    const text = String(raw).trim();
    if (!text) return null;
    if (Object.prototype.hasOwnProperty.call(UI, text)) return UI[text];
    if (byName.has(text)) return byName.get(text);
    if (tileName(text)) return tileName(text);
    let m;
    if ((m=/^n° (\d+) · (.+)$/.exec(text))) {
      const name = byName.get(m[2]) || UI[m[2]];
      if (name) return '第'+m[1]+'项 · '+name;
    }
    if ((m=/^n° (\d+) · (\d+) × (\d+) points?$/.exec(text)))
      return '第'+m[1]+'项 · '+m[2]+' × '+m[3]+'分';
    if ((m=/^(\d+) pts?$/.exec(text))) return m[1]+'分';
    if ((m=/^(Est|Sud|Ouest|Nord)\s*(◆)?$/.exec(text))) return tileNames[m[1]] + (m[2]?' ◆':'');
    if ((m=/^Main incomplète : (\d+)\/(\d+) tuiles cachées\.$/.exec(text)))
      return '手牌未完成：'+m[1]+'/'+m[2]+'张暗牌。';
    if ((m=/^Main trop longue : (\d+) tuiles cachées, (\d+) maximum pour ces éléments\.$/.exec(text)))
      return '暗牌过多：现有'+m[1]+'张，这些面子最多允许'+m[2]+'张。';
    if ((m=/^✓ (\d+) fans? · (\d+) points \(minimum : 8 hors fleurs\) — (vérifier les cumuls|contrôle conseillé)\.$/.exec(text)))
      return '✓ '+m[1]+'个番种 · '+m[2]+'分（起和至少8分，不含花牌）——'+(m[3].includes('vérifier')?'请核对番种组合。':'建议复核。');
    if ((m=/^✕ (\d+) fans? · (\d+)\/8 points — HU non autorisé\.$/.exec(text)))
      return '✕ '+m[1]+'个番种 · '+m[2]+'/8分——尚不能和牌。';
    if ((m=/^(\d+)\/8 points — minimum non atteint\.$/.exec(text)))
      return m[1]+'/8分——未达到起和条件。';
    if ((m=/^Proposition sur (\d+) structure\(s\) analysée\(s\) ; (\d+) sorte\(s\) de tuile gagnante possibles \(analyse structurelle\)\.$/.exec(text)))
      return '已分析'+m[1]+'种手牌结构；可能的和牌张类型为'+m[2]+'种（仅结构分析）。';
    if ((m=/^Il faut (\d+) tuile\(s\) cachée\(s\) pour analyser les attentes avec ces éléments déclarés ; tu en as (\d+)\.$/.exec(text)))
      return '当前已声明的面子需要'+m[1]+'张暗牌才能分析听牌；现在有'+m[2]+'张。';
    if ((m=/^Attentes structurelles : (\d+) type\(s\) de tuile\. Seules les mains d’au moins 8 points hors fleurs permettent HU\.$/.exec(text)))
      return '结构听牌：'+m[1]+'种牌。番种得分至少8分（不含花牌）才能和牌。';
    if ((m=/^(\d+) points?$/.exec(text))) return m[1]+'分';
    if ((m=/^Fan n°(\d+) (.+)$/.exec(text)))return '第'+m[1]+'项 '+(byName.get(m[2])||m[2]);
    if ((m=/^Ajouter (.+)$/.exec(text))) return '添加'+(tileName(m[1])||m[1]);
    if ((m=/^Retirer (.+)$/.exec(text))) return '移除'+(tileName(m[1])||m[1]);
    if ((m=/^Choisir (.+) comme tuile gagnante \(HU\)$/.exec(text))) return '将'+(tileName(m[1])||m[1])+'标为和牌张';
    if ((m=/^Compléter avec (.+)$/.exec(text)))return '用'+(tileName(m[1])||m[1])+'完成和牌';
    if ((m=/^Kong caché \+ Kong exposé$/.exec(text)))return '暗杠 + 明杠';
    if (text === 'Rechercher un fan…') return '搜索番种名称或编号…';
    if (text === 'Rechercher un fan') return '搜索番种';
    if (text === 'Filtrer les fans') return '筛选番种';
    if (text === 'Filtrer par points') return '按分值筛选';
    if (text === 'Fan n° 81') return '第81项';
    if (text === 'Fleurs') return '花牌';
    if (text === 'Copie ce texte :') return '请复制以下文本：';
    if (text === 'Kong caché + Kong exposé') return '暗杠 + 明杠';
    return null;
  };
  const preserveWhitespace = (original, content) => {
    if (content === null) return original;
    const a = /^\s*/.exec(original)[0];
    const b = /\s*$/.exec(original)[0];
    return a + content + b;
  };
  function translateNode(node) {
    if (!node || !node.parentElement || node.parentElement.closest('script,style,textarea')) return;
    let prev=nodeOriginal.get(node);
    if (prev === undefined) {prev=node.nodeValue;nodeOriginal.set(node,prev);}
    else if (node.nodeValue!==prev && node.nodeValue!==preserveWhitespace(prev,zh(prev))) {
      prev=node.nodeValue;nodeOriginal.set(node,prev);
    }
    const desired=locale==='fr'?prev:preserveWhitespace(prev,zh(prev));
    if (node.nodeValue!==desired)node.nodeValue=desired;
  }
  function translateAttributes(element) {
    let old=attributeOriginal.get(element);
    if (!old){old={};attributeOriginal.set(element,old);}
    for(const attr of ['placeholder','title','aria-label','alt']) {
      if(!element.hasAttribute(attr))continue;
      const now=element.getAttribute(attr);
      if(!(attr in old))old[attr]=now;
      else if(now!==old[attr] && now!== (zh(old[attr])||old[attr]))old[attr]=now;
      const desired=locale==='fr'?old[attr]:(zh(old[attr])||old[attr]);
      if(now!==desired)element.setAttribute(attr,desired);
    }
  }
  function applyAll(root=document.body) {
    if(!root)return;
    if(root.nodeType===Node.TEXT_NODE){translateNode(root);return;}
    if(root.nodeType!==Node.ELEMENT_NODE)return;
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    if(root instanceof Element)translateAttributes(root);
    let node;
    while((node=walker.nextNode()))translateNode(node);
    if(root.querySelectorAll) for(const el of root.querySelectorAll('[placeholder],[title],[aria-label],[alt]'))translateAttributes(el);
  }
  // Observer les zones recalculées, sans jamais modifier les données du moteur.
  let pending=false;
  const observer=new MutationObserver(() => {
    if(pending)return;
    pending=true;
    queueMicrotask(()=>{pending=false;applyAll();});
  });
  observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['title','placeholder','aria-label','alt']});
  const nativeCatalog=renderCatalog;
  renderCatalog=function(){
    const q=document.getElementById('searchFan').value.trim().toLocaleLowerCase();
    if(locale!=='zh-Hans'||!q||/^\d+$/.test(q)){nativeCatalog();return;}
    const field=document.getElementById('searchFan');
    field.value='';
    try{nativeCatalog();}finally{field.value=q;}
    const host=document.getElementById('catalog');
    let count=0;
    for(const row of Array.from(host.querySelectorAll('.fan-item'))){
      const match=row.querySelector('strong')?.textContent?.match(/^n° (\d+) ·/);
      const id=match?Number(match[1]):0;
      const f=FANS_ZH[id-1];
      if(!f)continue;
      const corpus=[String(id),f.frName,f.frDesc,f.zhName,f.zhDesc].join(' ').toLocaleLowerCase();
      if(!corpus.includes(q)) row.remove(); else count++;
    }
    if(!count){
      host.innerHTML='';
      const p=document.createElement('p');p.className='empty';p.textContent='Aucun fan pour cette recherche.';host.append(p);
    }
  };
  document.getElementById('searchFan').oninput=()=>renderCatalog();
  document.getElementById('filterFan').onchange=()=>renderCatalog();
  const oldCopy=document.getElementById('copy').onclick;
  document.getElementById('copy').onclick=()=>{
    if(locale!=='zh-Hans')return oldCopy();
    const sc=activeFanData();
    const title=manual?'MCR手动计分':'MCR自动计分建议';
    const lines=sc.selected.map(f=>`#${f.id} ${FANS_ZH[f.id-1]?.zhName||f.name}: ${f.count} × ${f.points} = ${f.count*f.points}`).join('\n');
    const winds=['东','南','西','北'];
    const text=[title,`计入番种：${sc.fanCount}`,`番种得分（不含花牌）：${sc.base}`,`花牌加分：${sc.flowers}`,`合计：${sc.total}`,lines,`和牌条件：${state.mode==='self'?'自摸':'点和'}；圈风${winds[state.tableWind-27]}；门风${winds[state.seatWind-27]}。`,'正式确认前请核对番种组合。'].join('\n');
    const done=()=>toast('计分结果已复制！');
    if(navigator.clipboard?.writeText)navigator.clipboard.writeText(text).then(done).catch(()=>prompt('请复制以下文本：',text));
    else {const ta=document.createElement('textarea');ta.value=text;document.body.append(ta);ta.select();try{document.execCommand('copy');done();}catch(e){prompt('请复制以下文本：',text);}ta.remove();}
  };
  const setLanguage=(newLocale)=>{
    locale=newLocale==='zh-Hans'?'zh-Hans':'fr';
    document.documentElement.lang=locale==='zh-Hans'?'zh-Hans':'fr';
    select.value=locale;
    document.title=locale==='zh-Hans'?'国标麻将 MCR — V12 双语计分器':'MAHJONG MCR — V12, tuiles originales';
    try{localStorage.setItem('mahjong-mcr-language',locale);}catch(_){}
    // Les champs, les points et les tuiles sélectionnées demeurent inchangés.
    render();applyAll();
  };
  select.onchange=()=>setLanguage(select.value);
  let saved='fr';try{saved=localStorage.getItem('mahjong-mcr-language')||'fr';}catch(_){}
  setLanguage(saved);
  window.MCR_LANGUAGE={get:()=>locale,set:setLanguage,fanNames:FANS_ZH.map(f=>f.zhName)};
})();
