# Calculateur Mahjong MCR V12.1 — La Baie de Jade

Correctif du moteur V12 à partir de l'archive originale conservée. Moteur et interface bilingues français / chinois simplifié. Les 42 images PNG sont inchangées.

## Corrections
1. La valorisation du vent du joueur ou du vent dominant ne doit pas effacer les fan n°73 indépendants portant sur des Pungs de 1 ou de 9. Elle ne doit pas non plus faire oublier le Pung d'extrémité indépendant d'un fan Trois Grands Vents.
2. Le vent du joueur et le joueur gagnant sont maintenant synchronisés dans les deux sens. Le score est recalculé lors du changement de gagnant.

## Déployer sur GitHub Pages (méthode ZIP actuelle)
Le dépôt `TomGEEKZONE/calculateur-mcr` contient un workflow `.github/workflows/deploy.yml` qui décompresse une archive ZIP avant de publier le site.
1. Conserver l'ancien ZIP V12 comme sauvegarde pour le moment.
2. Importer `Calculateur_MCR_V12_1_GitHub_Pages.zip` à la racine de ce dépôt.
3. Dans `.github/workflows/deploy.yml`, remplacer exactement le nom de l'ancienne archive dans la commande `unzip` :
   `Calculateur_MCR_V12_GitHub_Pages.zip` → `Calculateur_MCR_V12_1_GitHub_Pages.zip`.
4. Enregistrer (Commit changes) sur la branche main. Le workflow doit redéployer le site.
5. Vérifier que l'en-tête affiche `V12.1` et reproduire les deux mains du rapport. Ne supprimer l'ancienne archive qu'après vérification.

Les fichiers sont statiques (index.html, i18n.js, assets/*). Pour utiliser un site sous un chemin `/calculateur-mcr/`, les URLs des images sont relatives.

## Limite réglementaire
Le décompte automatique est un outil d'assistance et les tests ne garantissent pas l'exhaustivité des 81 fans, des conditions de victoire et de leurs cumuls. Une validation humaine reste nécessaire pour les cas complexes.

Références :
- WMO, Mahjong Competition Rules, juillet 2006, https://mahjong-europe.org/portal/images/docs/mcr_EN.pdf
- FFMJ, Description des combinaisons, mai 2013, https://www.ffmahjong.fr/FFMJ-site/documents/GuideFFMJ_MCR.pdf
