/* Calculateur MCR V12.2 : cache hors ligne intégré, limité à ce dépôt GitHub Pages.
   Le service worker ne touche pas au moteur de calcul et à ses données. */
const VERSION = 'mcr-calculator-v12.2-20261123';
const PRECACHE = [
  "./",
  "./index.html",
  "./i18n.js",
  "./offline.js",
  "./manifest.webmanifest",
  "./manifest_images.json",
  "./icon-192.png",
  "./icon-512.png",
  "./assets/bambous/1.png",
  "./assets/bambous/2.png",
  "./assets/bambous/3.png",
  "./assets/bambous/4.png",
  "./assets/bambous/5.png",
  "./assets/bambous/6.png",
  "./assets/bambous/7.png",
  "./assets/bambous/8.png",
  "./assets/bambous/9.png",
  "./assets/caracteres/1.png",
  "./assets/caracteres/2.png",
  "./assets/caracteres/3.png",
  "./assets/caracteres/4.png",
  "./assets/caracteres/5.png",
  "./assets/caracteres/6.png",
  "./assets/caracteres/7.png",
  "./assets/caracteres/8.png",
  "./assets/caracteres/9.png",
  "./assets/cercles/1.png",
  "./assets/cercles/2.png",
  "./assets/cercles/3.png",
  "./assets/cercles/4.png",
  "./assets/cercles/5.png",
  "./assets/cercles/6.png",
  "./assets/cercles/7.png",
  "./assets/cercles/8.png",
  "./assets/cercles/9.png",
  "./assets/dragons/blanc.png",
  "./assets/dragons/rouge.png",
  "./assets/dragons/vert.png",
  "./assets/fleurs_saisons/automne.png",
  "./assets/fleurs_saisons/bambou.png",
  "./assets/fleurs_saisons/chrysantheme.png",
  "./assets/fleurs_saisons/ete.png",
  "./assets/fleurs_saisons/hiver.png",
  "./assets/fleurs_saisons/orchidee.png",
  "./assets/fleurs_saisons/printemps.png",
  "./assets/fleurs_saisons/prunier.png",
  "./assets/vents/est.png",
  "./assets/vents/nord.png",
  "./assets/vents/ouest.png",
  "./assets/vents/sud.png"
];
const ROOT = new URL(self.registration.scope);

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    // Une installation est valide uniquement si TOUTES les ressources sont chargées.
    await cache.addAll(PRECACHE);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('mcr-calculator-') && name !== VERSION)
      .map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== ROOT.origin || !url.pathname.startsWith(ROOT.pathname)) return;

  event.respondWith((async () => {
    const cache = await caches.open(VERSION);
    // Toutes les ressources de l'interface utilisent la version complète mise en cache.
    // On ne remplace pas une partie seulement de la version (HTML / scripts / tuiles).
    if (request.mode === 'navigate') {
      const entry = await cache.match('./index.html');
      if (entry) return entry;
    }
    const hit = await cache.match(request);
    if (hit) return hit;
    try {
      const response = await fetch(request);
      // Les ressources non prévues dans le cache restent accessibles en ligne.
      return response;
    } catch (error) {
      if (request.mode === 'navigate') {
        const entry = await cache.match('./index.html');
        if (entry) return entry;
      }
      throw error;
    }
  })());
});
