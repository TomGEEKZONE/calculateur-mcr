# Calculateur Mahjong MCR V12.2 — La Baie de Jade

Version V12.1 + fonctionnement hors ligne (PWA), sans modification du moteur MCR ni des 42 illustrations originales.

## Publication GitHub Pages
Dépôt prévu : `TomGEEKZONE/calculateur-mcr`, branche `main`.

1. Ajouter `Calculateur_MCR_V12_2_GitHub_Pages.zip` à la racine du dépôt.
2. Remplacer `.github/workflows/deploy.yml` par le fichier `deploy.yml` fourni séparément.
3. Vérifier que les deux tâches GitHub Actions `build` puis `deploy` deviennent vertes.
4. Ouvrir `https://tomgeekzone.github.io/calculateur-mcr/` en ligne : vérifier l'en-tête `V12.2`.
5. Attendre la mention « Prêt pour une utilisation hors connexion » avant d'activer le mode avion.
6. Sur iPhone, ouvrir le site dans Safari, puis Partager → Sur l'écran d'accueil.
7. Tester de nouveau l'ouverture depuis l'écran d'accueil avec le mode avion activé.

Conserver la V12.1 comme version de secours ; ne pas supprimer son ZIP lors de cette opération.

## Architecture PWA
- `sw.js` : préchargement atomique du HTML, des 42 PNG et des fichiers complémentaires ;
  cache limité au périmètre `/calculateur-mcr/` ; les autres applications ne sont pas modifiées.
- `offline.js` : indicateur de préparation hors ligne, message en français et chinois simplifié.
- `manifest.webmanifest` : installation sur écran d'accueil, URL de départ et scope relatifs.
- `icon-192.png`, `icon-512.png` : icônes dédiées à l'application (sans changement des logos officiels).
- `index.html` : ajout des métadonnées PWA et indicateur hors ligne ; moteur de calcul identique à la V12.1.
- `i18n.js`, `assets/*` : fichiers inchangés, octet par octet.

Le cache du navigateur peut être supprimé par l'utilisateur, le navigateur ou le système.
Une connexion est indispensable lors de la première préparation ou après effacement du cache.
Les liens externes (sites de référence) nécessitent Internet. Une vérification réglementaire
humaine reste nécessaire pour les décomptes complexes.

## Tests
- Vérification SHA-256 des 42 PNG, du fichier `i18n.js` et des scripts internes du moteur : identiques à la V12.1.
- Simulation du service worker : 50 ressources stockées, ouverture et chargement de tuiles sans réseau, conservation des autres caches.
- Régression Chromium en mémoire : trois exemples donnant les mêmes scores, traduction chinois simplifié, affichage mobile sans débordement.
- Un véritable essai hors ligne sur iPhone/Safari reste à effectuer après déploiement : le navigateur du laboratoire interdit les navigations locales.
