/* Indicateur de préparation hors connexion ; aucun changement du moteur MCR. */
(() => {
  'use strict';
  const box = document.getElementById('offlineStatus');
  const message = document.getElementById('offlineText');
  const reload = document.getElementById('offlineReload');
  if (!box || !message) return;

  const CACHE = 'mcr-calculator-v12.2-20261123';
  const isChinese = () => document.documentElement.lang.toLowerCase().startsWith('zh');
  const texts = {
    fr: {
      preparing: 'Préparation du mode hors connexion…',
      ready: 'Prêt pour une utilisation hors connexion',
      offline: 'Hors ligne · calculateur disponible',
      incomplete: 'Mode hors connexion indisponible. Reconnecte-toi, puis recharge cette page.',
      update: 'Nouvelle version installée · actualise pour l’ouvrir',
      reload: 'Actualiser'
    },
    zh: {
      preparing: '正在准备离线使用…',
      ready: '已准备好离线使用',
      offline: '离线 · 计算器可用',
      incomplete: '离线内容尚未准备好，请联网后重新打开页面。',
      update: '新版本已安装，请刷新页面',
      reload: '刷新'
    }
  };
  let status = 'preparing';
  let requiresReload = false;
  const trans = () => texts[isChinese() ? 'zh' : 'fr'];
  const display = (next) => {
    status = next;
    const label = trans();
    message.textContent = label[next] || label.preparing;
    box.classList.toggle('ready', next === 'ready' || next === 'offline' || next === 'update');
    box.classList.toggle('error', next === 'incomplete');
    reload.hidden = next !== 'update';
    reload.textContent = label.reload;
  };
  reload.addEventListener('click', () => location.reload());
  new MutationObserver(() => display(status)).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  const refresh = () => display(status === 'ready' || status === 'offline' ?
    (navigator.onLine ? 'ready' : 'offline') : status);
  window.addEventListener('online', refresh);
  window.addEventListener('offline', refresh);

  async function verifyReady() {
    try {
      // Le cache n'est considéré comme prêt qu'après installation réussie du SW.
      if (!('serviceWorker' in navigator) || !('caches' in window)) {
        display('incomplete'); return;
      }
      const names = await caches.keys();
      if (!names.includes(CACHE)) { display('preparing'); return; }
      const current = await caches.open(CACHE);
      // L'installation ne doit pas être déclarée terminée si des images manquent.
      if ((await current.keys()).length < 50) { display('preparing'); return; }
      const critical = ['./index.html','./i18n.js','./offline.js','./manifest.webmanifest'];
      for (const path of critical) {
        if (!await current.match(path)) { display('preparing'); return; }
      }
      const reg = await navigator.serviceWorker.getRegistration('./');
      if (!reg || !reg.active) { display('preparing'); return; }
      if (!requiresReload) display(navigator.onLine ? 'ready' : 'offline');
    } catch (err) { display('incomplete'); }
  }

  async function start() {
    if (!('serviceWorker' in navigator) || !('caches' in window)) {
      display('incomplete'); return;
    }
    try {
      const hadController = !!navigator.serviceWorker.controller;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (hadController) { requiresReload = true; display('update'); }
        else void verifyReady();
      });
      // On peut disposer d'un cache valide même en l'absence de réseau.
      await verifyReady();
      try {
        await navigator.serviceWorker.register('./sw.js', {scope:'./',updateViaCache:'none'});
        await navigator.serviceWorker.ready;
      } catch (err) {
        // Une demande de mise à jour en échec ne détruit pas le cache existant.
      }
      await verifyReady();
    } catch (err) { display('incomplete'); }
  }
  display('preparing');
  void start();
})();
